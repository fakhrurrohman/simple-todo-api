const express = require('express');
const bodyParser = require('body-parser');
const todoRoutes = require('./routes/todos');

const app = express();
app.use(bodyParser.json());

app.use('/todos', todoRoutes);

app.listen(3000, () => {
  console.log('Starter server listening on http://localhost:3000');
});
